// pages/protected.tsx
import { getSession } from "next-auth/react";
import { GetServerSideProps } from "next";

const ProtectedPage = () => {
  return (
    <div>
      <h1>Protected Content</h1>
      <p>This is a protected page, you need to be logged in to see it.</p>
    </div>
  );
};

export const getServerSideProps: GetServerSideProps = async (context) => {
  const session = await getSession({ req: context.req });

  if (!session) {
    return {
      redirect: {
        destination: '/auth/signin',
        permanent: false,
      },
    };
  }

  return {
    props: { session },
  };
};

export default ProtectedPage;
